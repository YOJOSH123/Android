package com.example.inclasskotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun Calculate(view: View) {
        var NumOneBox = findViewById<EditText>(R.id.txtNumOne)
        var NumTwoBox = findViewById<EditText>(R.id.txtNumTwo)
        var radioGroup = findViewById<RadioGroup>(R.id.operation)
        var idButton = radioGroup.checkedRadioButtonId
        var typeButton = findViewById<RadioButton>(idButton)
        var result = findViewById<TextView>(R.id.txtResult)
        var NumOne = NumOneBox.text.toString().toInt()
        var NumTwo = NumTwoBox.text.toString().toInt()
        var total:Int

        if(typeButton.text.toString() == "Add"){
            total = NumOne+NumTwo
        }else{
            total = NumOne-NumTwo
        }

        result.text = total.toString()
    }
}