package com.example.groupactivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun SaveAccount(view: View) {
        var NameBox = findViewById<EditText>(R.id.txtName)
        var radioButtonGroup = findViewById<RadioGroup>(R.id.rbSavingsType)
        var idButton = radioButtonGroup.checkedRadioButtonId
        var accountButton = findViewById<RadioButton>(idButton)
        var accountType: String
        var amountBox = findViewById<EditText>(R.id.txtAmount)

        if(accountButton.text.toString() == "Checking"){
            accountType = "Checking"
        }else{
            accountType = "Savings"
        }

        val accountTypeWhen = when(accountButton.text.toString()){
            "Checking"->"CheckingAccount"
            "Savings"->"SavingsAccount"
            else->"Other"
        }

        var Amount = amountBox.text.toString().toFloat()

        var Name = NameBox.text.toString()

        val MyAccount = BankAccount(Name,accountType,Amount)

        Toast.makeText(applicationContext, MyAccount.type, Toast.LENGTH_LONG).show()
    }
}