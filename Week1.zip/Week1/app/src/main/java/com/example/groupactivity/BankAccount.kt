package com.example.groupactivity

data class BankAccount(val name : String = "", val type: String = "", var balance: Float = 0.0f) {

}